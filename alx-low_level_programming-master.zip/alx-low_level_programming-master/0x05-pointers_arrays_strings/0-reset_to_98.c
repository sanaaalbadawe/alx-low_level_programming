#include "main.h"

/**
 * reset_to_98 - updates the value of the variable
 * the pointer points to to 98
 * @n: pointer to the variable to update
 */
void reset_to_98(int *n)
{
	*n = 98;
}
