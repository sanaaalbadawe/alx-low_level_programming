# 0x15. C - File
## Resources:
### Read or watch:

[File descriptors](https://en.wikipedia.org/wiki/File_descriptor)


[C Programming in Linux Tutorial #024 - open() read() write() Functions](https://www.youtube.com/watch?v=dP3N8g7h8gY)

